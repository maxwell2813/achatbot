const discord = require("discord.js");
const client = new discord.Client();

function commandIs(str, msg){
    return msg.content.toLowerCase().startsWith("$" + str)
}

// 8Ball function 
function ANice8Ball() {
    var rand = ['It is decidedly so', 'Without a doubt', 'Yes, definitely', 'You may rely on it', 'As I see it, yes', 'Most likely', 'Outlook good', 'Yes', 'Signs point to yes', 'Reply hazy try again', 'Ask again later', 'Better not tell you now', 'Cannot predict now', 'Concentrate and ask again', 'Do not count on it', 'My reply is no', 'My sources say no', 'Outlook not so good', 'Very doubtful'];

    return rand[Math.floor(Math.random()*rand.length)];
}

client.on('ready', () => {
    console.log('The bot is online!');
});

client.on('message', message => {
    var args = message.content.split(/[ ]+/);
    if(commandIs("hello", message)){
        message.channel.sendMessage('Hello there, ' + message.author.username);
    }

	//About command
    if(commandIs("about", message)){
        message.reply('I was programmed by Maxwell2813. You can view my commands by typeing $Help');
    }

	//Help command
    if(commandIs("help", message)){
        message.reply('My current commands are: $Help $Hello $About $Say $Warning $Meme and $Complaints. More should be added soon.');
    }

	//Ping command, used for testing
    if(commandIs("ping", message)){
        message.reply('pong');
    }

	//Say command, can be abused
    if(commandIs("say", message)){
        if(args.length ===1){
            message.channel.sendMessage('You broke it, good job. Next time use !say [message]');
        } else {
            message.channel.sendMessage(args.join(" ").substring(5));
        }
    }

    if(commandIs("warning", message)){
        message.reply('If Maxwell2813 finds the $say command to be abused it will be removed.');
    }

    if(commandIs("complaints", message)){
        message.reply(':page_with_curl: :candle:');
    }

    if(commandIs("meme", message)){
        message.reply('http://i.imgur.com/6PlRXhI.gif');
    }

    if(commandIs("nah", message)){
        message.reply('Say is currently disabled thanks to a glitch.');
    }

    if(commandIs("cookie", message)){
        if(args.length === 1){
         message.channel.sendMessage('Use $cookie @username Next time!');
        } else {
            message.guild.member(message.mentions.users.first().sendMessage('Test'));
        }  
    }
	// 8ball command
	if(commandIs("8ball", message)) {
		message.reply('Your anwser is: ' + ANice8Ball());
	}
	
	// Flip a coin command
	 if (commandIs("flip", message)) {
    	var result = Math.floor((Math.random() * 2) + 1);
    	if (result == 1) {
    		message.reply("The coin landed on heads");
    	} else if (result == 2) {
    		message.reply("The coin landed on tails");
    	}
    }
			  
	
})


client.login('MzAxNTg2MDY5ODIzMTYwMzIy.C89JgQ.tvbAP0RO7rh4JR1SSBjXWg6MAdM');